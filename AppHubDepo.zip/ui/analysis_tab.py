import threading
import tkinter as tk
from tkinter import ttk, messagebox
from analysis import find_and_rename_order_dbs, aggregate_order_quantities, compute_shortages
from sync import download_order_dbs
from db import Database

class AnalysisTab:
    def __init__(self, parent, db: Database, status_callback=None, progress_widget=None):
        self.db = db
        self.status_callback = status_callback
        self.progress = progress_widget

        self.frame = ttk.Frame(parent)
        self.frame.pack(fill="both", expand=True)

        top = ttk.Frame(self.frame)
        top.pack(fill="x", pady=5)
        self.status = tk.Label(top, text="Analiz bekleniyor", fg="purple")
        self.status.pack(side="left", padx=5)
        ttk.Button(top, text="Analiz Yap", command=self._on_analyze).pack(side="right", padx=5)

        cols = ("Kod","Talep","Stok","Eksik")
        self.tree = ttk.Treeview(self.frame, columns=cols, show="headings")
        for c in cols:
            self.tree.heading(c, text=c); self.tree.column(c, anchor=tk.CENTER)
        self.tree.pack(fill="both", expand=True, padx=5, pady=5)

    def _on_analyze(self):
        if self.status_callback:
            self.status_callback("Analiz yapılıyor...", "orange", True)
        else:
            self.status.config(text="Analiz yapılıyor...", fg="orange")
            if self.progress: self.progress.start()
        threading.Thread(target=self._run_analysis, daemon=True).start()

    def _run_analysis(self):
        download_order_dbs(callback=None)
        dbs = find_and_rename_order_dbs()
        shipped = self.db.get_shipped_barkods()
        req = aggregate_order_quantities(dbs, shipped, self.db.conn)
        stock = self.db.fetch_stock()
        sh = compute_shortages(req, stock)

        def gui_update():
            for iid in self.tree.get_children(): self.tree.delete(iid)
            if not sh:
                messagebox.showinfo("Sonuç","Eksik yok")
            else:
                for code, (r,s,m) in sh.items():
                    self.tree.insert("", "end", values=(code,r,s,m))
            if self.status_callback:
                self.status_callback("Analiz tamamlandı", "green", False)
            else:
                self.status.config(text="Analiz tamamlandı", fg="green")
                if self.progress: self.progress.stop()
        self.frame.after(0, gui_update)
