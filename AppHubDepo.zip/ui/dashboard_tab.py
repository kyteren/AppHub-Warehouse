# ui/dashboard_tab.py
import os
import sqlite3
import tkinter as tk
from tkinter import ttk
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from db import Database
from analysis import find_and_rename_order_dbs

class DashboardTab:
    """Stok, eksiklik ve sipariş bazlı pasta grafik gösteren Dashboard sekmesi"""
    def __init__(self, parent, db: Database):
        self.db = db
        self.frame = ttk.Frame(parent)
        self.frame.pack(fill="both", expand=True, padx=5, pady=5)

        # Sipariş seçimi
        sel_frame = ttk.Frame(self.frame)
        sel_frame.pack(fill="x", pady=(0,5), padx=5)
        ttk.Label(sel_frame, text="Sipariş Seç:").pack(side="left")
        self.order_var = tk.StringVar()
        self.combo = ttk.Combobox(sel_frame, textvariable=self.order_var, state="readonly")
        self.combo.pack(side="left", fill="x", expand=True, padx=(5,0))
        self.combo.bind("<<ComboboxSelected>>", lambda e: self._draw_order_pie())

        # Grafik alanı
        self.chart_frame = ttk.Frame(self.frame)
        self.chart_frame.pack(fill="both", expand=True)

        # Sipariş DB haritası
        self.order_db_map = {}

        # Verileri yükle
        self._load_orders()

    def _load_orders(self):
        db_files = find_and_rename_order_dbs()
        orders = []
        for dbf in db_files:
            conn = sqlite3.connect(dbf)
            cur = conn.cursor()
            try:
                cur.execute("SELECT barkod FROM orders")
                for (b,) in cur.fetchall():
                    orders.append(b)
                    self.order_db_map[b] = dbf
            except sqlite3.OperationalError:
                pass
            conn.close()
        self.combo['values'] = orders
        if orders:
            self.combo.current(0)
            self._draw_order_pie()

    def _draw_order_pie(self):
        barkod = self.order_var.get()
        if not barkod:
            return
        # Önce grafikleri temizle
        for w in self.chart_frame.winfo_children():
            w.destroy()

        # İlgili sipariş DB’sini bul
        dbf = self.order_db_map.get(barkod)
        if not dbf:
            return
        conn = sqlite3.connect(dbf)
        cur = conn.cursor()
        try:
            cur.execute(
                "SELECT urun_kod, miktar FROM order_items WHERE barkod=?",
                (barkod,)
            )
            items = cur.fetchall()
        except sqlite3.OperationalError:
            items = []
        conn.close()

        stock = self.db.fetch_stock()

        # 1) Dış halka: sipariş miktarları
        labels = []
        order_vals = []
        # 2) İç halkayı hazırlamak için stok ve eksik
        stock_vals = []
        missing_vals = []
        for kod, miktar in items:
            try:
                qty = float(miktar)
            except (ValueError, TypeError):
                qty = 0.0
            stok_qty = stock.get(kod, (None, 0.0))[1]
            miss    = max(0.0, qty - stok_qty)
            avail   = min(stok_qty, qty)

            labels.append(kod)
            order_vals.append(qty)
            stock_vals.append(avail)
            missing_vals.append(miss)

        # Oluştur: iki halkalı pasta grafiği
        fig = Figure(figsize=(6, 6))
        ax  = fig.add_subplot(111)

        # Dış halka (sipariş miktarları)
        wedges_outer, _ = ax.pie(
            order_vals,
            radius=1.0,
            labels=labels,
            labeldistance=1.05,
            colors=['lightblue']*len(labels),
            wedgeprops=dict(width=0.3, edgecolor='white')
        )

        # İç halka (stok ve eksik)
        inner_vals   = []
        inner_colors = []
        for i in range(len(labels)):
            inner_vals.extend([stock_vals[i], missing_vals[i]])
            inner_colors.extend(['green', 'red'])
        # İç halkaya metin etiketleri hazırlayalım
        labels_inner = []
        for i in range(len(labels)):
            labels_inner.append(str(int(stock_vals[i])))
            labels_inner.append(str(int(missing_vals[i])))

        wedges_inner, texts_inner = ax.pie(
            inner_vals,
            radius=0.7,
            labels=labels_inner,
            labeldistance=0.6,
            textprops={'fontsize': 8, 'color': 'white'},
            colors=inner_colors,
            wedgeprops=dict(width=0.3, edgecolor='white')
        )

        ax.set_title(f"Sipariş {barkod} Dağılımı ve Stok/Eksik", pad=20)
        ax.legend(
            [wedges_inner[0], wedges_inner[1]],
            ['Stok', 'Eksik'],
            loc='center left',
            bbox_to_anchor=(1, 0, 0.5, 1)
        )

        canvas = FigureCanvasTkAgg(fig, master=self.chart_frame)
        canvas.get_tk_widget().pack(fill="both", expand=True)
        canvas.draw()

# Canvas
canvas = FigureCanvasTkAgg(fig, master=self.chart_frame)
canvas.get_tk_widget().pack(fill="both", expand=True)
canvas.draw()
