# ui/shipment_tab.py
import os
import shutil
import sqlite3
import threading
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from PyPDF2 import PdfReader
from db import Database
from sync import download_order_dbs
from analysis import find_and_rename_order_dbs
from config import LOCAL_ORDERS_DIR, INVOICE_DIR

class OrdersChangeHandler(FileSystemEventHandler):
    """Watchdog handler: orders klasöründe değişiklik olunca çağrılır."""
    def __init__(self, callback):
        self.callback = callback

    def on_modified(self, event):
        # Her değişiklikte otomatik yenile
        self.callback()

class ShipmentTab:
    """Depo çıkış işlemleri, otomatik sipariş yenileme ve geçmiş detay yönetimi."""
    def __init__(self, parent, db: Database, status_callback=None, progress_widget=None):
        self.db = db
        self.status_callback = status_callback
        self.progress = progress_widget

        # Ana frame
        self.frame = ttk.Frame(parent)
        self.frame.pack(fill="both", expand=True)

        # Watchdog: orders klasörünü izle
        handler = OrdersChangeHandler(self._on_refresh)
        self.observer = Observer()
        self.observer.schedule(handler, LOCAL_ORDERS_DIR, recursive=True)
        self.observer.start()

        # Üst kontrol çubuğu: durum + manuel yenile
        top = ttk.Frame(self.frame)
        top.pack(fill="x", pady=5, padx=5)
        self.order_status = tk.Label(top, text="Siparişler bekleniyor...", fg="purple")
        self.order_status.pack(side="left")
        ttk.Button(top, text="Yenile Sipariş", command=self._on_refresh).pack(side="right")

        # Bekleyen barkodlar
        ttk.Label(self.frame, text="Çıkış Bekleyen:").pack(anchor="w", padx=5)
        self.tree_pending = ttk.Treeview(self.frame, columns=("barkod",), show="headings", height=5)
        self.tree_pending.heading("barkod", text="Barkod")
        self.tree_pending.pack(fill="x", padx=5, pady=2)

        # Çıkış ve irsaliye butonları
        btns = ttk.Frame(self.frame)
        btns.pack(fill="x", pady=5, padx=5)
        ttk.Button(btns, text="Çıkış Yap",     command=self.process_shipment).pack(side="left", padx=5)
        ttk.Button(btns, text="İrsaliye Ekle", command=self.attach_invoice).pack(side="left", padx=5)

        # Çıkış geçmişi
        ttk.Label(self.frame, text="Çıkış Geçmişi:").pack(anchor="w", padx=5, pady=(10,0))
        cols = ("barkod","date","invoice_no","invoice")
        self.tree_hist = ttk.Treeview(self.frame, columns=cols, show="headings", height=8)
        for col, w in (("barkod",100),("date",150),("invoice_no",100),("invoice",80)):
            self.tree_hist.heading(col, text=col.title())
            self.tree_hist.column(col, width=w, anchor="center")
        self.tree_hist.pack(fill="both", expand=True, padx=5, pady=2)
        self.tree_hist.bind("<Double-1>", self.on_history_double_click)

        # İlk yüklemeler
        self._on_refresh()
        self.load_history()

    def _on_refresh(self):
        """Manuel veya otomatik yenileme tetikleyicisi."""
        if self.status_callback:
            self.status_callback("Siparişler yenileniyor...", "orange", True)
        else:
            self.order_status.config(text="Siparişler yenileniyor...", fg="orange")
            if self.progress: self.progress.start()

        threading.Thread(target=self._refresh_orders, daemon=True).start()

    def _refresh_orders(self):
        download_order_dbs(callback=lambda m, c, r=None: None)
        dbs = find_and_rename_order_dbs()
        shipped = self.db.get_shipped_barkods()

        def gui_update():
            self.tree_pending.delete(*self.tree_pending.get_children())
            for db_file in dbs:
                co = sqlite3.connect(db_file); cu = co.cursor()
                cu.execute("SELECT barkod FROM orders")
                for (barkod,) in cu.fetchall():
                    if barkod not in shipped:
                        self.tree_pending.insert("", "end", values=(barkod,))
                co.close()
            if self.status_callback:
                self.status_callback("Siparişler güncellendi", "green", False)
            else:
                self.order_status.config(text="Siparişler güncellendi", fg="green")
                if self.progress: self.progress.stop()

        self.frame.after(0, gui_update)

    def load_history(self):
        """Geçmiş treeview’ını doldur."""
        self.tree_hist.delete(*self.tree_hist.get_children())
        for sid, barkod, date, inv_no, inv_path in self.db.fetch_shipment_history():
            label = "Aç" if inv_path else ""
            self.tree_hist.insert(
                "", "end",
                values=(barkod, date, inv_no or "", label),
                tags=(str(sid),)
            )

    def process_shipment(self):
        """Seçili barkod için çıkış işlemi yap & DB kaydet."""
        sel = self.tree_pending.selection()
        if not sel:
            return
        barkod = self.tree_pending.item(sel[0], "values")[0]
        plate  = simpledialog.askstring("Araç Plaka", "Plaka:") or ""
        driver = simpledialog.askstring("Sürücü Adı", "Sürücü:") or ""
        tc     = simpledialog.askstring("TC Kimlik No", "TC Kimlik:") or ""
        note   = simpledialog.askstring("Not (opsiyonel)", "Not:") or ""
        sid    = self.db.record_shipment(barkod, plate, driver, tc, note)
        self.load_history()
        self.tree_pending.delete(sel[0])
        messagebox.showinfo("Başarılı", f"Çıkış kaydedildi: {barkod} (ID: {sid})")

    def attach_invoice(self):
        """Seçili geçmiş kaydına PDF irsaliye ekle & PDF’den numara al."""
        sel = self.tree_hist.selection()
        if not sel:
            return
        sid = int(self.tree_hist.item(sel[0], "tags")[0])
        pdf_path = filedialog.askopenfilename(title="PDF Seç", filetypes=[("PDF","*.pdf")])
        if not pdf_path:
            return

        reader = PdfReader(pdf_path)
        text = "".join(page.extract_text() or "" for page in reader.pages)
        import re
        m = re.search(r"Fatura\s*No[:\s]*([A-Za-z0-9-]+)", text)
        inv_no = m.group(1) if m else ""

        dest = os.path.join(INVOICE_DIR, f"{sid}.pdf")
        shutil.copy2(pdf_path, dest)
        self.db.add_invoice_path(sid, dest, invoice_number=inv_no)
        self.load_history()

    def on_history_double_click(self, event):
        """Çift tıklamayla detay popup’ı."""
        item = self.tree_hist.identify_row(event.y)
        if not item:
            return
        sid = int(self.tree_hist.item(item, "tags")[0])

        cur = self.db.conn.cursor()
        cur.execute(
            "SELECT barkod, shipped_at, vehicle_plate, driver, tc, note, invoice_number, invoice_path "
            "FROM shipments WHERE id=?", (sid,)
        )
        row = cur.fetchone()
        if not row:
            return

        cur.execute(
            "SELECT urun_kod, qty_shipped FROM shipment_items WHERE shipment_id=?", (sid,)
        )
        items = cur.fetchall()

        detail = tk.Toplevel(self.frame)
        detail.title(f"Çıkış Detayları — ID {sid}")
        detail.geometry("450x450")

        txt = tk.Text(detail, wrap="word", state="normal")
        txt.insert("end",
            f"Barkod: {row[0]}\n"
            f"Tarih: {row[1]}\n"
            f"Plaka: {row[2]}\n"
            f"Sürücü: {row[3]}\n"
            f"TC: {row[4]}\n"
            f"Not: {row[5]}\n"
            f"Fatura No: {row[6] or 'Yok'}\n\n"
            "Gönderilen Ürünler:\n"
        )
        for code, qty in items:
            txt.insert("end", f" - {code}: {qty}\n")
        txt.config(state="disabled")
        txt.pack(fill="both", expand=True, padx=10, pady=(10,0))

        inv_path = row[7]
        if inv_path:
            ttk.Button(detail, text="Fatura Aç", command=lambda: os.startfile(inv_path)).pack(pady=5)
        ttk.Button(detail, text="Kapat", command=detail.destroy).pack(pady=(0,10))
