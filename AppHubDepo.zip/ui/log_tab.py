import tkinter as tk
from tkinter import ttk
from tkinter.scrolledtext import ScrolledText
from config import LOG_FILE

class LogTab:
    """Uygulama log dosyasını gösteren sekme"""
    def __init__(self, parent):
        self.frame = ttk.Frame(parent)
        self.frame.pack(fill="both", expand=True, padx=5, pady=5)

        # Yenile butonu
        btn = ttk.Button(self.frame, text="Yenile", command=self._load_logs)
        btn.pack(anchor="ne")

        # ScrolledText log görüntüleyici
        self.txt = ScrolledText(self.frame, state="disabled")
        self.txt.pack(fill="both", expand=True, pady=(5,0))

        self._load_logs()

    def _load_logs(self):
        self.txt.config(state="normal")
        self.txt.delete("1.0", tk.END)
        try:
            with open(LOG_FILE, "r", encoding="utf-8", errors="replace") as f:
                self.txt.insert(tk.END, f.read())
        except FileNotFoundError:
            self.txt.insert(tk.END, "Henüz log dosyası oluşturulmadı.")
        self.txt.config(state="disabled")
