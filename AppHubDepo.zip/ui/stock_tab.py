import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from db import Database

class StockTab:
    """Hammadde ve Ürün stoklarını yöneten sekme (arama/filtre özelliği)"""
    def __init__(self, parent, db: Database):
        self.db = db
        self.frame = ttk.Frame(parent)
        self.frame.pack(fill="both", expand=True)

        search_frame = ttk.Frame(self.frame)
        search_frame.pack(fill="x", pady=(5,0), padx=5)
        ttk.Label(search_frame, text="Ara:").pack(side="left")
        self.search_var = tk.StringVar()
        ttk.Entry(search_frame, textvariable=self.search_var).pack(side="left", fill="x", expand=True, padx=(5,0))
        self.search_var.trace_add("write", lambda *_: self._filter_stock())

        pw = ttk.Panedwindow(self.frame, orient=tk.HORIZONTAL)
        pw.pack(fill="both", expand=True, padx=5, pady=5)

        lf1 = ttk.Labelframe(pw, text="Hammadde")
        self.tree_hamm = ttk.Treeview(lf1, columns=("code","type","qty"), show="headings")
        for col, txt in (("code","Kod"), ("type","Tip"), ("qty","Miktar")):
            self.tree_hamm.heading(col, text=txt)
            self.tree_hamm.column(col, anchor=tk.CENTER)
        self.tree_hamm.pack(fill="both", expand=True)
        pw.add(lf1, weight=1)

        lf2 = ttk.Labelframe(pw, text="Ürün")
        self.tree_prod = ttk.Treeview(lf2, columns=("code","type","qty"), show="headings")
        for col, txt in (("code","Kod"), ("type","Tip"), ("qty","Miktar")):
            self.tree_prod.heading(col, text=txt)
            self.tree_prod.column(col, anchor=tk.CENTER)
        self.tree_prod.pack(fill="both", expand=True)
        pw.add(lf2, weight=1)

        btns = ttk.Frame(self.frame)
        btns.pack(fill="x", pady=5, padx=5)
        ttk.Button(btns, text="Yeni Hammadde", command=lambda: self._add_stock("hammadde")).pack(side="left", padx=2)
        ttk.Button(btns, text="Yeni Ürün",     command=lambda: self._add_stock("ürün")).pack(side="left", padx=2)
        ttk.Button(btns, text="Miktar Güncelle", command=self._update_stock).pack(side="left", padx=2)
        ttk.Button(btns, text="Açıklama Güncelle", command=self._update_desc).pack(side="left", padx=2)
        ttk.Button(btns, text="Sil", command=self._remove_stock).pack(side="left", padx=2)
        ttk.Button(btns, text="Yenile", command=self.refresh_stock).pack(side="right", padx=2)

        self._all_data = {}
        self.refresh_stock()

    def refresh_stock(self):
        self._all_data = self.db.fetch_stock()
        self._filter_stock()

    def _filter_stock(self):
        q = self.search_var.get().lower()
        for tree in (self.tree_hamm, self.tree_prod):
            for iid in tree.get_children():
                tree.delete(iid)
        for name, (typ, qty) in self._all_data.items():
            if q and q not in name.lower() and q not in typ.lower():
                continue
            if typ.lower().startswith("hammadde"):
                self.tree_hamm.insert("", "end", values=(name, typ, qty))
            else:
                self.tree_prod.insert("", "end", values=(name, typ, qty))

    def _add_stock(self, category: str):
        name = simpledialog.askstring("Yeni Ekle", "Malzeme adı:")
        if not name: return
        desc = simpledialog.askstring("Açıklama", "Açıklama:") or ""
        self.db.upsert_stock(name, f"{category}: {desc}", 0)
        self.refresh_stock()

    def _update_stock(self):
        for tree in (self.tree_hamm, self.tree_prod):
            sel = tree.selection()
            if sel:
                name, typ, qty = tree.item(sel[0], "values")
                new_qty = simpledialog.askfloat("Miktar Güncelle", f"{name} yeni miktar:", initialvalue=float(qty), minvalue=0)
                if new_qty is not None:
                    self.db.upsert_stock(name, typ, new_qty)
                    self.refresh_stock()
                return
        messagebox.showwarning("Uyarı", "Öğe seçin.")

    def _update_desc(self):
        for tree in (self.tree_hamm, self.tree_prod):
            sel = tree.selection()
            if sel:
                name, typ, qty = tree.item(sel[0], "values")
                base, old = typ.split(":",1) if ":" in typ else (typ, "")
                new_desc = simpledialog.askstring("Açıklama Güncelle", f"{name} açıklama:", initialvalue=old.strip())
                if new_desc is not None:
                    self.db.update_item_description(name, f"{base}: {new_desc}")
                    self.refresh_stock()
                return
        messagebox.showwarning("Uyarı", "Öğe seçin.")

    def _remove_stock(self):
        for tree in (self.tree_hamm, self.tree_prod):
            sel = tree.selection()
            if sel:
                name = tree.item(sel[0], "values")[0]
                if messagebox.askyesno("Sil", f"{name} silinsin mi?"):
                    self.db.delete_item(name)
                    self.refresh_stock()
                return
