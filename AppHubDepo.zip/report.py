import csv
import os
import smtplib
import tempfile
from email.message import EmailMessage
from db import Database
from analysis import Analyzer
from config import SMTP_SERVER, SMTP_PORT, SMTP_USER, SMTP_PASSWORD, EMAIL_FROM, EMAIL_TO

def generate_csv_report(db: Database) -> str:
    analyzer = Analyzer(db)
    shortages = analyzer.compute_shortages()
    fd, path = tempfile.mkstemp(prefix="stok_rapor_", suffix=".csv")
    os.close(fd)
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Ürün Kodu","Tip","Miktar","Eksik Miktar"])
        for name, (typ, qty) in db.fetch_stock().items():
            eksik = shortages.get(name, 0)
            writer.writerow([name, typ, qty, eksik])
    return path

def send_weekly_report():
    db = Database()
    csv_path = generate_csv_report(db)
    msg = EmailMessage()
    msg["Subject"] = "Haftalık Stok & Eksiklik Raporu"
    msg["From"] = EMAIL_FROM
    msg["To"] = EMAIL_TO
    msg.set_content("Merhaba,\n\nHaftalık stok ve eksiklik raporunu ekte bulabilirsiniz.\n")
    with open(csv_path, "rb") as f:
        data = f.read()
    msg.add_attachment(data, maintype="text", subtype="csv", filename=os.path.basename(csv_path))
    with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as smtp:
        smtp.starttls()
        smtp.login(SMTP_USER, SMTP_PASSWORD)
        smtp.send_message(msg)
    os.remove(csv_path)
