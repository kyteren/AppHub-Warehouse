import os
import subprocess
import sys

# SQLite veritabanı
DB_PATH = os.getenv("DB_PATH", "warehouse.db")

# Rclone ayarları
RCLONE_REMOTE = os.getenv("RCLONE_REMOTE", "mega:warehouse")
ORDER_REMOTE_ROOT = os.getenv("ORDER_REMOTE_ROOT", "mega:Malzeme_Talep_Formu")

# Yerel dizinler
LOCAL_ORDERS_DIR = os.getenv("LOCAL_ORDERS_DIR", "orders")
INVOICE_DIR = os.getenv("INVOICE_DIR", "invoices")

# Senkronizasyon aralığı (saniye)
SYNC_INTERVAL_SEC = int(os.getenv("SYNC_INTERVAL_SEC", "30"))

# Logging
LOG_FILE = os.getenv("LOG_FILE", "warehouse_app.log")

# SMTP / e-posta ayarları
SMTP_SERVER   = os.getenv("SMTP_SERVER", "smtp.example.com")
SMTP_PORT     = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER     = os.getenv("SMTP_USER", "kullanici@example.com")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "sifreniz")
EMAIL_FROM    = os.getenv("EMAIL_FROM", SMTP_USER)
EMAIL_TO      = os.getenv("EMAIL_TO", "sana@example.com")

# Windows için subprocess flags
HIDE_FLAGS = {'creationflags': subprocess.CREATE_NO_WINDOW} if sys.platform.startswith('win') else {}
