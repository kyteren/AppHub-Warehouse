import os
import sqlite3
from typing import Dict, List, Optional, Set, Tuple
from datetime import datetime
from config import DB_PATH, LOCAL_ORDERS_DIR, INVOICE_DIR

class Database:
    """Veritabanı bağlantısı, tablo oluşturma ve CRUD/evrak yönetimi"""

    def __init__(self, db_path: str = DB_PATH):
        os.makedirs(LOCAL_ORDERS_DIR, exist_ok=True)
        os.makedirs(INVOICE_DIR, exist_ok=True)

        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.execute("PRAGMA journal_mode=WAL;")
        self.cur = self.conn.cursor()
        self._initialize_schema()

    def _initialize_schema(self) -> None:
        self.cur.execute("""
            CREATE TABLE IF NOT EXISTS items (
                name TEXT PRIMARY KEY,
                type TEXT,
                quantity REAL DEFAULT 0
            )
        """)
        self.cur.execute("""
            CREATE TABLE IF NOT EXISTS shipments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                barkod TEXT,
                shipped_at TEXT,
                vehicle_plate TEXT,
                driver TEXT,
                tc TEXT,
                note TEXT,
                invoice_number TEXT,
                invoice_path TEXT
            )
        """)
        self.cur.execute("""
            CREATE TABLE IF NOT EXISTS shipment_items (
                shipment_id INTEGER,
                urun_kod TEXT,
                qty_shipped REAL,
                FOREIGN KEY(shipment_id) REFERENCES shipments(id)
            )
        """)
        # Index’ler
        self.cur.execute("CREATE INDEX IF NOT EXISTS idx_shipment_time ON shipments(shipped_at)")
        self.cur.execute("CREATE INDEX IF NOT EXISTS idx_item_code ON shipment_items(urun_kod)")
        self.conn.commit()

    def fetch_stock(self) -> Dict[str, Tuple[str, float]]:
        self.cur.execute("SELECT name, type, quantity FROM items")
        return {r[0]: (r[1], r[2]) for r in self.cur.fetchall()}

    def upsert_stock(self, name: str, type_: str, qty: float) -> None:
        if self.cur.execute("SELECT 1 FROM items WHERE name=?", (name,)).fetchone():
            self.cur.execute(
                "UPDATE items SET type=?, quantity=? WHERE name=?",
                (type_, qty, name)
            )
        else:
            self.cur.execute(
                "INSERT INTO items(name,type,quantity) VALUES(?,?,?)",
                (name, type_, qty)
            )
        self.conn.commit()

    def update_item_description(self, name: str, new_type: str) -> None:
        self.cur.execute("UPDATE items SET type=? WHERE name=?", (new_type, name))
        self.conn.commit()

    def delete_item(self, name: str) -> None:
        self.cur.execute("DELETE FROM items WHERE name=?", (name,))
        self.conn.commit()

    def record_shipment(self, barkod: str, plate: str, driver: str, tc: str, note: str = "") -> int:
        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        self.cur.execute("""
            INSERT INTO shipments
              (barkod, shipped_at, vehicle_plate, driver, tc, note)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (barkod, now, plate, driver, tc, note))
        sid = self.cur.lastrowid
        self.conn.commit()
        return sid

    def record_shipment_items(self, shipment_id: int, items: List[Tuple[str, float]]) -> None:
        self.cur.executemany(
            "INSERT INTO shipment_items(shipment_id, urun_kod, qty_shipped) VALUES (?, ?, ?)",
            [(shipment_id, k, q) for k, q in items]
        )
        self.conn.commit()

    def add_invoice_path(self, shipment_id: int, path: str, invoice_number: Optional[str] = None) -> None:
        if invoice_number:
            self.cur.execute(
                "UPDATE shipments SET invoice_path=?, invoice_number=? WHERE id=?",
                (path, invoice_number, shipment_id)
            )
        else:
            self.cur.execute(
                "UPDATE shipments SET invoice_path=? WHERE id=?",
                (path, shipment_id)
            )
        self.conn.commit()

    def get_shipped_barkods(self) -> Set[str]:
        self.cur.execute("SELECT barkod FROM shipments")
        return {r[0] for r in self.cur.fetchall()}

    def fetch_shipment_history(self) -> List[Tuple[int, str, str, Optional[str], Optional[str]]]:
        self.cur.execute("""
            SELECT id, barkod, shipped_at, invoice_number, invoice_path
            FROM shipments ORDER BY shipped_at DESC
        """)
        return self.cur.fetchall()

    def close(self) -> None:
        self.conn.close()
