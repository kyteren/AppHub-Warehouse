# analysis.py
import os
import shutil
import sqlite3
from db import Database
from config import LOCAL_ORDERS_DIR

class Analyzer:
    """Veritabanı üzerinden stok eksiklerini hesaplayan sınıf."""
    def __init__(self, db: Database):
        self.db = db

    def compute_shortages(self) -> dict:
        """
        Tüm stokları çeker; miktarı negatif olanların mutlak eksikliklerini döner.
        """
        shortages = {}
        for name, (typ, qty) in self.db.fetch_stock().items():
            if qty < 0:
                shortages[name] = abs(qty)
        return shortages


def find_and_rename_order_dbs():
    """
    LOCAL_ORDERS_DIR içindeki her kullanıcı klasöründen siparis.db dosyasını
    uygulama köküne kopyalar ve kopya adlarını liste olarak döner.
    """
    out = []
    for user in os.listdir(LOCAL_ORDERS_DIR):
        src = os.path.join(LOCAL_ORDERS_DIR, user, "siparis.db")
        if os.path.exists(src):
            dst = f"siparis_{user}.db"
            shutil.copy2(src, dst)
            out.append(dst)
    return out


def aggregate_order_quantities(db_list, shipped_set, conn):
    """
    order_items tablosundaki (barkod, urun_kod, miktar) kayıtlarını okuyup,
    henüz çıkışı yapılmamış barkodlar için ürün bazında toplam talep miktarını döner.
    Eğer yeni bir kod tespit edilirse, otomatik olarak "ürün:" tipiyle ekler.
    """
    agg = {}
    known = {k: v for k, v in Database().fetch_stock().items()}

    for db_file in db_list:
        co = sqlite3.connect(db_file)
        cu = co.cursor()
        cu.execute("SELECT barkod, urun_kod, miktar FROM order_items")
        for barkod, kod, miktar in cu.fetchall():
            if barkod in shipped_set:
                continue
            try:
                q = float(miktar)
            except ValueError:
                q = 0.0
            agg[kod] = agg.get(kod, 0.0) + q

            # Bilinmeyen ürün kodu otomatik ekle
            if kod not in known:
                Database().upsert_stock(kod, "ürün:", 0.0)
                known[kod] = ("ürün:", 0.0)
        co.close()
    return agg


def compute_shortages(requested, stock):
    """
    requested: dict {urun_kod: toplam_talep}
    stock:     dict {urun_kod: (type, quantity)}
    Talep > stok olanları (talep, stok, eksik miktar) şeklinde döner.
    """
    sh = {}
    for kod, talep in requested.items():
        stk = stock.get(kod, (None, 0.0))[1]
        if talep > stk:
            sh[kod] = (talep, stk, talep - stk)
    return sh
