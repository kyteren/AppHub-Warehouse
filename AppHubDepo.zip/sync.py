import os
import subprocess
import time
import json
from datetime import datetime
from config import (
    RCLONE_REMOTE,
    ORDER_REMOTE_ROOT,
    LOCAL_ORDERS_DIR,
    SYNC_INTERVAL_SEC,
    HIDE_FLAGS,
    DB_PATH
)

_last_sync_times = {'db': 0.0, 'orders': {}}

def sync_db_if_modified(callback=None):
    try:
        mtime = os.path.getmtime(DB_PATH)
    except FileNotFoundError:
        mtime = 0.0
    if mtime > _last_sync_times['db']:
        _last_sync_times['db'] = mtime
        if callback: callback("DB değişti; senkronize ediliyor...", "orange", True)
        subprocess.run(
            ["rclone", "copy", DB_PATH, f"{RCLONE_REMOTE}/{DB_PATH}", "--update"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **HIDE_FLAGS
        )
        if callback: callback(f"DB sync tamamlandı: {datetime.now().strftime('%H:%M:%S')}", "green", False)

def sync_orders_by_modtime(callback=None):
    try:
        out = subprocess.check_output(
            ["rclone", "lsjson", "-R", ORDER_REMOTE_ROOT],
            stderr=subprocess.DEVNULL, **HIDE_FLAGS
        )
        data = json.loads(out)
        for entry in data:
            if not entry.get("IsDir") and entry["Path"].endswith("siparis.db"):
                user = os.path.dirname(entry["Path"])
                remote_time = datetime.fromisoformat(entry["ModTime"]).timestamp()
                prev = _last_sync_times['orders'].get(user, 0.0)
                if remote_time > prev:
                    local_dir = os.path.join(LOCAL_ORDERS_DIR, user)
                    os.makedirs(local_dir, exist_ok=True)
                    subprocess.run(
                        ["rclone", "copy", f"{ORDER_REMOTE_ROOT}/{user}/siparis.db", local_dir, "--update"],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **HIDE_FLAGS
                    )
                    _last_sync_times['orders'][user] = remote_time
                    if callback: callback(f"{user} sipariş sync tamamlandı", "green", False)
    except Exception as e:
        if callback: callback(f"Sipariş sync hatası: {e}", "red", False)

def download_order_dbs(callback=None):
    sync_orders_by_modtime(callback)

def periodic_sync(callback=None):
    while True:
        sync_db_if_modified(callback)
        sync_orders_by_modtime(callback)
        time.sleep(SYNC_INTERVAL_SEC)
