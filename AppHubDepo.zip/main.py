import threading
import logging
import tkinter as tk
from tkinter import ttk
import schedule
import time

from report import send_weekly_report
from config import SYNC_INTERVAL_SEC, LOG_FILE
from db import Database
from sync import periodic_sync
from ui.stock_tab import StockTab
from ui.analysis_tab import AnalysisTab
from ui.shipment_tab import ShipmentTab
from ui.dashboard_tab import DashboardTab
from ui.log_tab import LogTab

def setup_logging():
    logging.basicConfig(
        filename=LOG_FILE,
        level=logging.INFO,
        format="%(asctime)s %(levelname)-8s %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    console.setFormatter(logging.Formatter("%(asctime)s %(levelname)-8s %(message)s"))
    logging.getLogger().addHandler(console)

class App:
    def __init__(self, root):
        setup_logging()
        logging.info("Uygulama başlatılıyor.")

        self.db = Database()
        root.title("Depo Yönetimi")
        root.geometry("1200x800")

        nb = ttk.Notebook(root)
        nb.pack(fill="both", expand=True)

        f_stock = ttk.Frame(nb)
        f_anal  = ttk.Frame(nb)
        f_ship  = ttk.Frame(nb)
        f_dash  = ttk.Frame(nb)
        f_log   = ttk.Frame(nb)

        nb.add(f_stock, text="Stock")
        nb.add(f_anal,  text="Talep Analiz")
        nb.add(f_ship,  text="Depo Çıkış")
        nb.add(f_dash,  text="Dashboard")
        nb.add(f_log,   text="Loglar")

        self.progress = ttk.Progressbar(root, mode="indeterminate")
        status_frame = ttk.Frame(root)
        status_frame.pack(fill="x", side="bottom")
        self.status = tk.Label(status_frame, text="Durum: Bekleniyor...", fg="blue")
        self.status.pack(side="left", padx=5)
        self.progress.pack(side="right", padx=5)

        StockTab(f_stock, self.db)
        AnalysisTab(f_anal, self.db, status_callback=self._update_status, progress_widget=self.progress)
        ShipmentTab(f_ship, self.db, status_callback=self._update_status, progress_widget=self.progress)
        DashboardTab(f_dash, self.db)
        LogTab(f_log)

        threading.Thread(
            target=lambda: periodic_sync(callback=self._update_status),
            daemon=True
        ).start()

        threading.Thread(target=self._start_report_scheduler, daemon=True).start()

    def _update_status(self, msg, color="black", running=False):
        def ui():
            self.status.config(text=f"Durum: {msg}", fg=color)
            if running: self.progress.start()
            else:       self.progress.stop()
        self.status.after(0, ui)

    def _start_report_scheduler(self):
        schedule.every().monday.at("08:00").do(send_weekly_report)
        while True:
            schedule.run_pending()
            time.sleep(60)

if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()
